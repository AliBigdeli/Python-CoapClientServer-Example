[![Build Status](https://travis-ci.org/Tanganelli/CoAPthon3.svg?branch=master)](https://travis-ci.org/Tanganelli/CoAPthon3)

# CoAPthon3
CoAPthon3 is a porting to python3 of my CoAPthon library. CoAPthon3 is a python3 library to the CoAP protocol compliant with the RFC. Branch is available for the Twisted framework.
